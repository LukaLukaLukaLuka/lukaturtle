This is a python package for a small improvement to the turtle package, adding the **shape** function.

```python
import lukaturtle as lt
lt.shape(3, 100)
```
The shape function takes two arguments: the number of sides and the length of each side.

Copyright Luka Lajnvaš 2025